import 'package:flutter/material.dart';

void main() {
  runApp(MeuApp());
}

class Tarefa {
  String titulo;

  Tarefa(this.titulo);
}

class MeuApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lista de Tarefas',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => TelaListaTarefas(),
        '/adicionarTarefa': (context) => TelaAdicionarTarefa(),
      },
    );
  }
}

class TelaListaTarefas extends StatefulWidget {
  @override
  _TelaListaTarefasState createState() => _TelaListaTarefasState();
}

class _TelaListaTarefasState extends State<TelaListaTarefas> {
  List<Tarefa> tarefas = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Tarefas'),
      ),
      body: ListView.builder(
        itemCount: tarefas.length,
        itemBuilder: (context, index) {
          return Dismissible(
            key: Key(tarefas[index].titulo),
            onDismissed: (direction) {
              setState(() {
                tarefas.removeAt(index);
              });
            },
            background: Container(
              color: Colors.red,
            ),
            child: ListTile(
              title: Text(tarefas[index].titulo),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final Tarefa = await Navigator.pushNamed(context, '/adicionarTarefa');
          if (Tarefa != null) {
            setState(() {
              tarefas.add;
            });
          }
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class TelaAdicionarTarefa extends StatelessWidget {
  final TextEditingController _controlador = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar Tarefa'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _controlador,
              decoration: InputDecoration(
                labelText: 'Título da Tarefa',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                String titulo = _controlador.text;
                if (titulo.isNotEmpty) {
                  Navigator.pop(context, Tarefa(titulo));
                }
              },
              child: Text('Adicionar Tarefa'),
            ),
          ],
        ),
      ),
    );
  }
}
