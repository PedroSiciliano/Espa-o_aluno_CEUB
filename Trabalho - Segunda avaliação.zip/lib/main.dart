import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => TarefaProvider(),
      child: MeuApp(),
    ),
  );
}

class Tarefa {
  String titulo;

  Tarefa(this.titulo);
}

class TarefaProvider extends ChangeNotifier {
  List<Tarefa> _tarefas = [];

  List<Tarefa> get tarefas => _tarefas;

  void adicionarTarefa(String titulo) {
    _tarefas.add(Tarefa(titulo));
    notifyListeners();
  }

  void removerTarefa(int index) {
    _tarefas.removeAt(index);
    notifyListeners();
  }
}

class MeuApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lista de Tarefas',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => TelaListaTarefas(),
        '/adicionarTarefa': (context) => TelaAdicionarTarefa(),
      },
    );
  }
}

class TelaListaTarefas extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Tarefas'),
      ),
      body: Consumer<TarefaProvider>(
        builder: (context, tarefaProvider, _) {
          return ListView.builder(
            itemCount: tarefaProvider.tarefas.length,
            itemBuilder: (context, index) {
              return Dismissible(
                key: Key(tarefaProvider.tarefas[index].titulo),
                onDismissed: (direction) {
                  tarefaProvider.removerTarefa(index);
                },
                background: Container(
                  color: Colors.red,
                ),
                child: ListTile(
                  title: Text(tarefaProvider.tarefas[index].titulo),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.pushNamed(context, '/adicionarTarefa');
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class TelaAdicionarTarefa extends StatelessWidget {
  final TextEditingController _controlador = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar Tarefa'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _controlador,
              decoration: InputDecoration(
                labelText: 'Título da Tarefa',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                String titulo = _controlador.text;
                if (titulo.isNotEmpty) {
                  Provider.of<TarefaProvider>(context, listen: false)
                      .adicionarTarefa(titulo);
                  Navigator.pop(context);
                }
              },
              child: Text('Adicionar Tarefa'),
            ),
          ],
        ),
      ),
    );
  }
}
